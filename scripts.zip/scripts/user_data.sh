#! /bin/bash

sudo yum update -y
sudo yum install git -y
sudo git clone https://github.com/JDAG-SUP/ULTIMA-NOTA-TELEMATICA
sudo yum install -y docker
sudo service docker start
